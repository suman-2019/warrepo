[![Build Status](https://travis-ci.org/chrishantha/sample-java-programs.svg?branch=master)](https://travis-ci.org/chrishantha/sample-java-programs)

Sample Java Programs
====================

This repository contains some sample programs. All are Maven projects and can be run directly using "java -jar"

## How to build

Run `mvn clean install` to build all sample programs

## License

Copyright (C) 2015 M. Isuru Tharanga Chrishantha Perera

Licensed under the Apache License, Version 2.0
